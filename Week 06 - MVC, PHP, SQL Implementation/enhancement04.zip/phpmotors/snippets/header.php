<header>
    <img id="logo" src="/phpmotors/images/site/logo.png" alt="Company Logo">
    <a id="acctLink" href="/phpmotors/accounts/index.php/?action=login">My Account</a>
</header>